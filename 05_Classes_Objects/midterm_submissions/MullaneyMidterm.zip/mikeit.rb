
require_relative 'lib/story'
require_relative 'lib/story_board'
require_relative 'lib/remote_source_nfl'
require_relative 'lib/remote_source_nba'
require_relative 'lib/remote_source_mlb'

def show_message(message)
  puts message
end

def get_input
  gets.chomp 
end

def get_choice
  gets.to_i
end

def show_menu
  show_message "Would you like to:"
  show_message "1. View the latest NFL stories?"
  show_message "2. View the latest NBA stories?"
  show_message "3. View the latest MLB stories?"
  show_message "4. Exit"
end

def add_remote_stories_nfl
  RemoteSourceNfl.get.each do |story|
    StoryBoard.add_story story
  end
end

def add_remote_stories_nba
  RemoteSourceNba.get.each do |story|
    StoryBoard.add_story story
  end
end

def add_remote_stories_mlb
  RemoteSourceMlb.get.each do |story|
    StoryBoard.add_story story
  end
end

def show_story_board
  StoryBoard.stories.each do |story|
    show_message story 
  end
end

show_message("Welcome to Mikeit! A major sports news aggregator.")
show_menu
loop do
  choice = get_choice
  StoryBoard.clear
  if choice == 1
    add_remote_stories_nfl
    show_story_board
    show_menu
  elsif choice == 2
    add_remote_stories_nba
    show_story_board
    show_menu
  elsif choice == 3
    add_remote_stories_mlb
    show_story_board
    show_menu
  elsif choice ==  4 
    break
  else
    show_message "Invalid Selection"
    show_menu
  end
end

puts "Thank you for using Mikeit!"
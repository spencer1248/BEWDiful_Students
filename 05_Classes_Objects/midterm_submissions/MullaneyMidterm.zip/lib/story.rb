class Story
  attr_reader :headline, :type
  def initialize(headline, type)
    @headline = headline
    @type = type
  end

end
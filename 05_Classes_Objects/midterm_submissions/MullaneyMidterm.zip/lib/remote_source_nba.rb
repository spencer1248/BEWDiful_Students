require 'json'
require 'rest-client'
require_relative 'story'

class RemoteSourceNba
  def self.get
    res = JSON.load(RestClient.get('http://api.espn.com/v1/sports/basketball/nba/news/?insider=no&apikey=vdshzc56s53juj5nv6p8yp85'))
    res["headlines"].map do |story|
      Story.new story["headline"], story["type"]
    end
  end
end
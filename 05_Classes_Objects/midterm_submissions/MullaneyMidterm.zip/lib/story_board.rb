class StoryBoard
  @@stories = []
  
  def self.clear
  	@@stories.clear
  end
  def self.add_story(story)
    @@stories << story
  end

  def self.stories
    @@stories.map do |story|
      "Story: #{story.headline}, Source: (#{story.type})"
    end
  end
end